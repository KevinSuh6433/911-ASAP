const functions = require("firebase-functions");
let client = require("twilio")(
    "AC0ab3adb6e07e760335493107b821aedc",
    "00a08879af786180cf5ab667b9ffa541"
);

const admin = require("firebase-admin");

admin.initializeApp(functions.config().firebase);


// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//  response.send("Hello from Firebase!");
// });


exports.sendMessage = functions.https.onRequest((req, res) => {

    const number = req.query.clientNumber;
    var NOK = [];
    var namePerson;
    var bloodType;
    var allergies;
    var medHist;


    // eslint-disable-next-line promise/always-return
    admin.firestore().collection("users").doc(number.toString()).get().then((doc) => {
        NOK = doc.data().emergencyContact;
        namePerson = doc.data().name;
        medHist = doc.data().medHist;
        bloodType = doc.data().bloodType;
        allergies = doc.data().allergies
    }).then(() => {
        client.messages.create({
            body: "Jerry Yang just called 911.",
            from: "+13342928335",
            to: "+16473093139"
            // eslint-disable-next-line promise/always-return
        }).then(() => {
            client.messages.create({
                body: "Name: Jerry Yang, Gender: Male, Blood Type: O, Allergies: Peanut, Medical History: Diabetes, Emergency Contact: Derek, 6473093139",
                from: "+13342928335",
                to: "+16478916433",

            })
        }).then(() => {
            res.send("SENT")
        }).catch((err) => {
            res.send(err)
        })


    })


});